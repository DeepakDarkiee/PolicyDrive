from django.shortcuts import render,redirect
from django.contrib.auth.models import User
from django.contrib import auth 
from django.urls import reverse_lazy
from django.urls import reverse
#from .forms import  ProfileForm
from django.contrib.auth.decorators import login_required
from django.contrib.auth import authenticate, login, logout
from django.http import HttpResponseRedirect, HttpResponse
from django.views.generic import TemplateView, View, ListView
from django.views.generic.edit import CreateView, UpdateView
from django.contrib import messages
from .models import Profile
from .forms import PasswordChangeForm 


def sign_up(request):
	if request.method == 'POST':
		if request.POST['password1'] == request.POST['password2']:
			try:
				user=User.objects.get(username=request.POST['username'])
				return render(request,'users/sign_up.html',{'error':'username is already taken'})
			except User.DoesNotExist:	
				user=User.objects.create_user(request.POST['username'], password=request.POST['password1'])
				auth.login(request,user)
				return redirect('/my_account')
			
		else:
			return render(request,'users/sign_up.html',{'error':'password doesn\'t matched'}) 
	
	else:	
		return render(request,'users/sign_up.html') 



def login(request):


	if request.method == 'POST':
		user=auth.authenticate(username=request.POST['username'],
							   password=request.POST['password'])
		if user is not None:
			auth.login(request,user)
			messages.success(request,"Successfully Logged in")
			return redirect('/my_account')
			#return redirect('/static/pdf/Brochure.pdf')    
		else:
			messages.error(request,"'username or password is incorrect!")
			return render(request,'users/login.html',{'massages':'username or password is incorrect!'}) 

	else:
		return render(request,'users/login.html') 	



@login_required
def user_logout(request):
    logout(request)
    messages.success(request,"Successfull Logged Out")
    return redirect("home")		


@login_required
def change_password(request):
    if request.method == 'POST':
        form = PasswordChangeForm(data=request.POST, user=request.user)
        if form.is_valid():
            user = form.save()
            update_session_auth_hash(request, form.user)  # Important!
            messages.success(request, 'Your password was successfully updated!')
            return redirect('home')
        else:
            messages.error(request, 'Please correct the error below.')
    else:
        form = PasswordChangeForm(request.user)
    return render(request, 'changepass.html', {
        'form': form
    })




@login_required
def edit_profile(request):
    context = {}
    check = Profile.objects.filter(user__id=request.user.id)
    if len(check)>0:
        data = Profile.objects.get(user__id=request.user.id)
        context["data"]=data    

    if request.method == "POST":
        user = User.objects.get(id=request.user.id)
        #user = User.objects.get(username = request.user)

        first_name  = request.POST.get('first_name') 
        last_name = request.POST.get('last_name')
        address = request.POST.get('address')        
        contact_number =request.POST.get('contact_number')        
        about_me= request.POST.get('about_me')
        profile_pic= request.POST.get('profile_pic')

        #user = User.objects.get(id=request.user.id)
        #user.first_name = first_name
        #user.last_name = last_name 
        #user.save()

        data.contact_number = contact_number
        data.first_name = first_name
        data.last_name = last_name
        data.about_me = about_me
        data.address = address
        data.save()

        if "image" in request.FILES:
            img = request.FILES["image"]
            data.profile_pic = img
            data.save()


        context["status"] = "Changes Saved Successfully"
    return render(request,"edit_profile.html",context)


