from django.urls import path
from users import views
# from users.views import Profile


urlpatterns = [
   
    path('login/', views.login, name='login'),
    path('sign_up/', views.sign_up, name='sign_up'),
    path('logout/',views.user_logout,name='logout'),

    path('change_password/',views.change_password,name='change_password'),
    
   	#path('profile/<int:pk>/',views.ProfileUpdateView.as_view(),name='profile'),
    path('edit_profile/',views.edit_profile,name="edit_profile"),

   
]


# if settings.DEBUG:
# 	urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)