from django.urls import path, re_path
from my_account import views
#from my_account.views import edit_profile


urlpatterns = [
    # Matches any html file - to be used for gentella
    # Avoid using your .html in your resources.
    # Or create a separate django app.
    re_path(r'^.*\.html', views.pages, name='pages'),
    # path('',views.pages, name='pages'),

    # The home page
    path('my_account/', views.index, name='index'),
    path('maps/', views.maps, name='maps'),
    #path('edit_profile/<int:pk>/', edit_profile.as_view(), name='edit_profile'),
]

