from fyers_api import accessToken

from fyers_api import fyersModel

app_id = "HZC120F9UL"

app_secret = "CLI4ALJ7RH"

app_session = accessToken.SessionModel(app_id, app_secret)

response = app_session.auth()

