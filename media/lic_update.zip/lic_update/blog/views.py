from django.shortcuts import render, redirect  
from django.http import HttpResponse,HttpResponseRedirect  
from django.contrib.auth.models import User
from django.contrib.auth.forms import UserCreationForm,AuthenticationForm
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.decorators import login_required
from django.core.mail import send_mail, BadHeaderError
from lic import settings  
from .forms import * 
from django.contrib.auth.decorators import login_required
from django.utils.decorators import method_decorator
from blog.models import Lic,contact_details
from django.contrib import messages
from django.core.paginator import Paginator, PageNotAnInteger, EmptyPage
from .models import Lic
from django.views import generic
from django.db.models import Q
from django.views.generic import TemplateView, ListView
#from .forms import LicForm  
  



def home(request):
    return render(request,'blog/home.html')


def about(request):
    return render(request,'blog/about.html')

def search(request):
    return render(request,'blog/search.html')


def services(request):
    return render(request,'blog/services.html')    



def contact(request):
    if request.method == 'GET':
        form = ContactForm()
    
    else:       
        form = ContactForm(request.POST)
        if form.is_valid():
            name =form.cleaned_data['name']
            phone_number = form.cleaned_data['phone_number']
            email = form.cleaned_data['email']
            message = form.cleaned_data['message']
            try:
                send_mail('subject',
            name+'is trying to contact you.\nDetails are: \n'+'\nName: '+name+' \nContact Number: '+
                    phone_number+'\nEmail: '+email+'\nMessage from sender: \n'+message,
                    settings.EMAIL_HOST_USER,
                    ['ishwarmandloi25@gmail.com','digitalspiritmakeiteasy@gmail.com','hr@makeiteasy.org.in',],
                    fail_silently=False)
            except BadHeaderError:
                return HttpResponse('Invalid header found')
            return redirect('contact')     
    return render(request, "blog/contact.html", {'form': form})



@login_required
def add_record(request):
    if request.method == "POST":
        user = User.objects.get(username = request.user)
        name  = request.POST.get('name') 
        email = request.POST.get('email')
        dob = request.POST.get('dob')
        contact =request.POST.get('contact')
        address = request.POST.get('address')
        policy_number=request.POST.get('policy_number')
        premium= request.POST.get('premium')
        sum_assured= request.POST.get('sum_assured')
        year_of_policy = request.POST.get('year_of_policy')
        beneficiary_name =request.POST.get('beneficiary_name')
        created_on =request.POST.get('created_on')
        renew_date=request.POST.get('renew_date')
        policy_type=request.POST.get('type')
        status=request.POST.get('status')
        #msg=request.POST.get(msg)
        obj=Lic(name=name,
        email=email,dob=dob,contact=contact,address = address,policy_number=policy_number,
        premium=premium,sum_assured=sum_assured,year_of_policy=year_of_policy,beneficiary_name=beneficiary_name,
        created_on=created_on,renew_date=renew_date,policy_type=policy_type,status=status,user = user)
        obj.save()
        messages.success(request,"Record Successfully")
        return redirect("/show_record")                 
    user = User.objects.get(username = request.user) 
    lics = Lic.objects.filter(user__pk=user.id)
    active = Lic.objects.filter(user__pk=user.id,status=1).count()
    count = lics.count()
            #print(count)
    return render(request,'add_record.html',{'lics':lics,'count':count,'active':active}) 
            
    


def digital_pms(request):
    if request.method == "POST":
        contact_name  = request.POST.get('contact_name') 
        phone_number = request.POST.get('phone_number')
        email = request.POST.get('email')
        obj=contact_details(contact_name=contact_name,phone_number=phone_number,email=email)
        obj.save()
        messages.success(request," Contact Successfully")
    return redirect('home')     


 

@login_required
def show_record(request):
    user = User.objects.get(username = request.user)
    # print(sorting)
    lics = Lic.objects.filter(user__pk=user.id)
    active = Lic.objects.filter(user__pk=user.id,status=1).count()
    count = lics.count()
    print(count)
    return render(request,'tables.html',{
        'lics':lics,
        'count':count,
        'active':active

        })  
    
            
def sort_record(request):
    user = User.objects.get(username = request.user)
    sorting = request.GET.get('sorting')
    lics = Lic.objects.filter(user__pk=user.id)
    active = Lic.objects.filter(user__pk=user.id,status=1).count()
    count = lics.count()
    print(sorting)
    if sorting is 'status':
        lics = Lic.objects.filter(user__pk=user.id,status=1).order_by('-created_on')
        return render(request,'tables.html',{
            'lics':lics,
             'count':count,
             'active':active

            })  
    else:
    
        lics = Lic.objects.filter(user__pk=user.id).order_by('-'+sorting)
        return render(request,'tables.html',{
            'lics':lics,
            'count':count,
             'active':active
            })  
    


@login_required
def edit_policy(request, id):  
    lics = Lic.objects.get(id=id)  
    return render(request,'edit_policy.html', {'lics':lics})            


@login_required
def update_policy(request, id):  
    lics = Lic.objects.get(id=id)  
    if request.method == "POST":
        user = User.objects.get(username = request.user)
        lics.name  = request.POST.get('name','') 
        lics.email = request.POST.get('email','')
        lics.dob = request.POST.get('dob','')
        lics.contact =request.POST.get('contact','')
        lics.address = request.POST.get('address','')
        lics.policy_number=request.POST.get('policy_number','')
        lics.premium= request.POST.get('premium','')
        lics.sum_assured= request.POST.get('sum_assured','')
        lics.year_of_policy = request.POST.get('year_of_policy','')
        lics.beneficiary_name =request.POST.get('beneficiary_name','')
        # lics.created_on =request.POST.get('created_on','')
        lics.renew_date=request.POST.get('renew_date','')
        lics.policy_type=request.POST.get('type','')
        lics.status=request.POST.get('status','')
        lics.save()

        messages.success(request,"Updated Successfully")
    return redirect('/show_record')




@login_required
def delete_policy(request, id):  
    lics = Lic.objects.get(id=id)  
    lics.delete()  
    return redirect('/show_record')  


# @login_required
# def show_record(request):
#     lics = Lic.objects.all()
#     #print(lics)
#     paginator = Paginator(lics, 3)  # 3 posts in each page
#     page = request.GET.get('page')
#     try:
#         lics = paginator.page(page)
#     except PageNotAnInteger:
#             # If page is not an integer deliver the first page
#         lics = paginator.page(1)
#     except EmptyPage:
#         # If page is out of range deliver last page of results
#         lics = paginator.page(paginator.num_pages)
#     return render(request,'tables.html',{'page': page,'lics': lics})


class SearchResultsView(ListView):
    model = Lic
    template_name = 'search_results.html'
    
    def get_queryset(self):
        query = self.request.GET.get('q') # new
        object_list = Lic.objects.filter(
            Q(name__icontains=query) | Q(policy_number__icontains=query)
        )
        return object_list



