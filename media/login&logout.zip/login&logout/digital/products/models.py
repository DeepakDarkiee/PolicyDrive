from django.db import models 
from django import forms  

class productss(models.Model):  
    pro_id = models.CharField(max_length=20)  
    pro_name = models.CharField(max_length=100)  
    com_email = models.EmailField()  
    com_contact = models.CharField(max_length=12)
    com_address = models.CharField(max_length=15)    
    
    class Meta:  
        db_table = "productss" 

    def __str__(self):
    	return self.pro_name    

    	