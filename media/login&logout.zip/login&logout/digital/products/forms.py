from django import forms  
from.models import *
from products.models import productss
from django.contrib.auth.models import User


class Products_Form(forms.ModelForm):  
    class Meta:  
        model = productss  
        fields = "__all__"  
