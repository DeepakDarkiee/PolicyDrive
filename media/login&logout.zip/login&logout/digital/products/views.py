from django.shortcuts import render
from django.contrib.auth.decorators import login_required
from products.forms import Products_Form 


# Create your views here.
def home(request):
	return render(request,'products/home.html')

@login_required
def create(request):
	if request.method == "POST":
		form = Products_Form(request.POST)
		if form.is_valid():
			try:
				form.save()
				return redirect('/show')
			except:
				pass

	else:
	
		form = Products_Form()
	return render(request,'products/create.html',{'form':form})	


