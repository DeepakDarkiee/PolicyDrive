from django.shortcuts import render, redirect  
from digital import settings  
from mysite.models import Employee  
from django.http import HttpResponse,HttpResponseRedirect  
from django import forms 
from .models import *
from .forms import *
from django .http import *
from django.contrib.auth.models import User
from django.contrib.auth.forms import UserCreationForm,AuthenticationForm
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.decorators import login_required
from django.core.mail import send_mail, BadHeaderError
#from reportlab.pdfgen import canvas  
from django.http import HttpResponse  
from io import BytesIO




def base_design(request):
    return render(request,'base_design.html')

def training(request):
    return render(request,'training.html')

def services(request):
    return render(request,'Services.html')    

def project(request):
    return render(request,'project.html')

def about(request):
    return render(request,'about.html')


def home(request):
    return render(request,'home.html')

def course(request):
    return render(request,'course.html')


def contact(request):
    sub = forms.Subscribe()
    if request.method == 'POST':
        sub = forms.Subscribe(request.POST)
        subject = 'Welcome to DataFlair'
        message = 'Hope you are enjoying your Django Tutorials'
        recepient = str(sub['Email'].value())
        send_mail(subject, 
            message, EMAIL_HOST_USER, [recepient], fail_silently = False)
        return render(request, 'subscribe/success.html', {'recepient': recepient})
    return render(request, 'subscribe/index.html', {'form':sub})









"""
def contact(request):
    if request.method == 'GET':
        form = ContactForm()
    
    else:
        
        form = ContactForm(request.POST)
        if form.is_valid():
            name =form.cleaned_data['name']
            phone_number = form.cleaned_data['phone_number']
            email = form.cleaned_data['email']
            message = form.cleaned_data['message']
            try:
                send_mail('Contact_Form',
                    email,
                    settings.EMAIL_HOST_USER,
                    ['makeiteasyon@gmail.com'],
                    fail_silently=False)
            except BadHeaderError:
                return HttpResponse('Invalid header found')
            return redirect('contact') 
    
    return render(request, "contact.html", {'form': form})               


"""
"""
def getpdf(request):
    # Create the HttpResponse object with the appropriate PDF headers.
    response = HttpResponse(content_type='application/pdf')
    response['Content-Disposition'] = 'attachment; filename="somefilename.pdf"'

    # Create the PDF object, using the response object as its "file."
    p = canvas.Canvas(response)

    # Draw things on the PDF. Here's where the PDF generation happens.
    # See the ReportLab documentation for the full list of functionality.
    p.drawString(100, 100, "Hello world.")

    # Close the PDF object cleanly, and we're done.
    p.showPage()
    p.save()
    return response

"""
"""
def contact(request):
    if request.method == 'GET':
        form = ContactForm()
    
    else:       
        form = ContactForm(request.POST)
        if form.is_valid():
            name =form.cleaned_data['name']
            phone_number = form.cleaned_data['phone_number']
            email = form.cleaned_data['email']
            message = form.cleaned_data['message']
            try:
                send_mail('subject',
                    '\n'+name+'is trying to contact you.\nDetails are : \n'
                    'Name : ' +name + '\n'
                    'Contact Number : ' + phone_number + '\n'
                    'Email : ' +email +'\n'
                    'message from sender : ' +message + '\n',
                    settings.EMAIL_HOST_USER,
                    ['ishwarmandloi25@gmail.com'],
                    fail_silently=False)
            except BadHeaderError:
                return HttpResponse('Invalid header found')
            return redirect('contact')     
    return render(request, "mac/contact.html", {'form': form}) 

"""
