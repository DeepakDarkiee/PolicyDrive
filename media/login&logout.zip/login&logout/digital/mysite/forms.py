
from django import forms  
from.models import *
from mysite.models import Employee
from django.contrib.auth.models import User  


class ContactForm(forms.Form):		
	name=forms.CharField(required=True)
	email=forms.EmailField(required=True)
	phone_number=forms.IntegerField(required=True)
	message=forms.CharField(required=True)
	
