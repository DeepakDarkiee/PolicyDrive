from django.urls import path,include
from accounts import views
from .views import  ChangePassword
#from django.contrib.auth.views import password_reset, password_reset_done 

urlpatterns = [ 

path('signup/',views.signup,name='signup'),
path('login/',views.login,name='login'),
#path('password_change/',views.password_change,name='password_change'),
#path('password_reset/', password_reset.as_view(), name = 'password_reset'),
#path('password_reset_done/', password_reset_done.as_view(), name='password_reset_done' ),
path('accounts/change-password/', ChangePassword.as_view(), name='change-password'),
path('logout/',views.user_logout,name='logout'),

]