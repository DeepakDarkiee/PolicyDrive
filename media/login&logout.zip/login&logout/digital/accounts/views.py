from django.shortcuts import render,redirect
from django.contrib.auth.models import User
from django.contrib import auth 
from django.urls import reverse
from django.contrib.auth.decorators import login_required
from django.contrib.auth import authenticate, login, logout
from django.http import HttpResponseRedirect, HttpResponse
from accounts.forms import ChangePasswordForm
from django.views.generic import TemplateView, View, ListView
from django.views.generic.edit import CreateView, UpdateView
 



def signup(request):
	if request.method == 'POST':
		if request.POST['password1'] == request.POST['password2']:
			try:
				user=User.objects.get(username=request.POST['username'])
				return render(request,'accounts/signup.html',{'error':'username is already taken'})
			except User.DoesNotExist:	
				user=User.objects.create_user(request.POST['username'], password=request.POST['password1'])
				auth.login(request,user)
				return redirect('home')
			
		else:
			return render(request,'accounts/signup.html',{'error':'password doesn\'t matched'}) 
	
	else:	
		return render(request,'accounts/signup.html') 




def login(request):

	if request.method == 'POST':
		user=auth.authenticate(username=request.POST['username'],
							   password=request.POST['password'])
		if user is not None:
			auth.login(request,user)
			return redirect('/products/create')
			#return redirect('/static/pdf/Brochure.pdf')    
		else:
			return render(request,'accounts/login.html',{'error':'username or password is incorrect!'}) 

	else:
		return render(request,'accounts/login.html') 	

"""
def password_change(request):
    if request.method == 'POST':
        form = PasswordChangeForm(request.user, request.POST)
        if form.is_valid():
            user = form.save()
            update_session_auth_hash(request, user)  # Important!
            messages.success(request, 'Your password was successfully updated!')
            return redirect('home')
        else:
            messages.error(request, 'Please correct the error below.')
    else:
        form = PasswordChangeForm(request.user)
    return render(request, 'accounts/password_change_form.html', {
        'form': form
    })
"""

@login_required
def user_logout(request):
    logout(request)
    return HttpResponseRedirect(reverse('home'))

class ChangePassword(View):
	template_name = 'accounts/change_password.html'
	def get(self, request):
		form = ChangePasswordForm()
		return render(request, self.template_name, {'form':form})

	def post(self, request):
		user = request.user
		old_password = request.POST.get('old_password')
		if user.check_password(old_password):
			if request.POST.get('new_password') == request.POST.get('confirm_password') and request.POST.get('new_password'):
				user.set_password(request.POST.get('new_password'))
				user.save()
				return redirect('/accounts/login')
			else:
				form = ChangePasswordForm()
				form.errors['confirm_password'] = 'Password and confirm password are different'
				return render(request, self.template_name, {'form':form})	
		else:
			form = ChangePasswordForm()
			form.errors['old_password'] = 'Old password is not correct'
			return render(request, self.template_name, {'form':form})