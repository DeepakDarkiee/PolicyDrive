from django.contrib import admin  
from django.urls import path  
from mysite import views  
from django.conf.urls import url,include
from django.urls import include, path

urlpatterns = [  
    path('',views.home,name='home'), 
    #path('pdf/',views.getpdf,name='getpdf'),  
    path('services/',views.services,name='services'),
    path('course/',views.course,name='course'),
    path('contact/',views.contact,name='contact'),
    path('project/',views.project,name='project'),    
    path('training/',views.training, name='training'),
    path('about/',views.about,name='about'), 
    path('admin/', admin.site.urls),  
    path('accounts/',include('accounts.urls')),
    path('products/',include('products.urls')),
    path('base_design/',views.base_design,name='base_design'),
    
    
    
] 