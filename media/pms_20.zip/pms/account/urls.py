from django.urls import path
from account import views


urlpatterns = [

	path("user_login",views.user_login,name="user_login"),
   	path("signup/",views.register,name="reg"),
	path("check_user/",views.check_user,name="check_user"),
	path("user_logout/",views.user_logout,name="user_logout"),
	path("edit_profile/",views.edit_profile,name="edit_profile"),
	path("change_password/",views.change_password,name="change_password"),
	path("forgotpass",views.forgotpass, name="forgotpass"),
  	path("reset_password",views.reset_password,name="reset_password"),
   
]
