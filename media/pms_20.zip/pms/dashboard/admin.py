from django.contrib import admin
from .models import(Lic,contact_details)
# Register your models here.
admin.site.register(Lic)
admin.site.register(contact_details)