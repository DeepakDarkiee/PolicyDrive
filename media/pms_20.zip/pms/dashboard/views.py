from django.shortcuts import render, redirect  
from django.http import HttpResponse,HttpResponseRedirect  
from django.contrib.auth.models import User
from django.contrib.auth.forms import UserCreationForm,AuthenticationForm
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.decorators import login_required
from django.core.mail import send_mail, BadHeaderError
from pms import settings  
from django.utils.decorators import method_decorator
#from .forms import * 
from .models import Lic
from django.contrib import messages
from django.contrib.auth.decorators import login_required
from django.shortcuts import render, get_object_or_404, redirect
from django.template import loader
from django.http import HttpResponse
from django import template
from django.contrib.auth.models import User
from django.views.generic import TemplateView, ListView
from django.db.models import Q
from dashboard.models import Lic
from django.contrib.auth.models import User
from datetime import datetime, timedelta
from django.contrib import messages
from django.conf import settings

@login_required
def index(request):
    user = User.objects.get(username = request.user)
    lics = Lic.objects.filter(user__pk=user.id)
    userMail=request.user.get_username()
    duesInTwoDays= Lic.objects.filter(user__pk=user.id,renew_date__range=[datetime.now().date(),datetime.now().date()+timedelta(days=2)],status=1).order_by('renew_date')
    duesInWeek= Lic.objects.filter(user__pk=user.id,renew_date__range=[datetime.now().date(),datetime.now().date()+timedelta(days=7)],status=1).order_by('renew_date')
    # settings.MAIL(userMail)
    return render(request,'dashboard/index.html',{
        'towDaysDues':duesInTwoDays,
        'weekDues':duesInWeek
        })

@login_required
def performance(request):
    return render(request,'dashboard/performance.html')   



@login_required
def add_record(request):
    if request.method == "POST":
        user = User.objects.get(username = request.user)
        name  = request.POST.get('name') 
        email = request.POST.get('email')
        dob = request.POST.get('dob')
        contact =request.POST.get('contact')
        address = request.POST.get('address')
        policy_number=request.POST.get('policy_number')
        premium= request.POST.get('premium')
        sum_assured= request.POST.get('sum_assured')
        year_of_policy = request.POST.get('year_of_policy')
        beneficiary_name =request.POST.get('beneficiary_name')
        created_on =request.POST.get('created_on')
        renew_date=request.POST.get('renew_date')
        policy_type=request.POST.get('type')
        status=request.POST.get('status')
        #msg=request.POST.get(msg)
        obj=Lic(name=name,
        email=email,dob=dob,contact=contact,address = address,policy_number=policy_number,
        premium=premium,sum_assured=sum_assured,year_of_policy=year_of_policy,beneficiary_name=beneficiary_name,
        created_on=created_on,renew_date=renew_date,policy_type=policy_type,status=status,user = user)
        obj.save()
        messages.success(request, 'Successfully Saved')
        return redirect("/show_record")                 
    
    return render(request,'dashboard/add_record.html') 
            
     
    
@login_required
def show_record(request):
    user = User.objects.get(username = request.user)   
    lics = Lic.objects.filter(user__pk=user.id)
    return render(request,'dashboard/show_record.html',{'lics':lics,})   


@login_required
def edit_policy(request, id):  
    lics = Lic.objects.get(id=id) 
    return render(request,'dashboard/edit_policy.html', {'lics':lics})      





@login_required
def update_policy(request, id):  
    lics = Lic.objects.get(id=id)  
    if request.method == "POST":
        user = User.objects.get(username = request.user)
        lics.name  = request.POST.get('name','') 
        lics.email = request.POST.get('email','')
        lics.dob = request.POST.get('dob','')
        lics.contact =request.POST.get('contact','')
        lics.address = request.POST.get('address','')
        lics.policy_number=request.POST.get('policy_number','')
        lics.premium= request.POST.get('premium','')
        lics.sum_assured= request.POST.get('sum_assured','')
        lics.year_of_policy = request.POST.get('year_of_policy','')
        lics.beneficiary_name =request.POST.get('beneficiary_name','')
        # lics.created_on =request.POST.get('created_on','')
        lics.renew_date=request.POST.get('renew_date','')
        lics.policy_type=request.POST.get('type','')
        lics.status=request.POST.get('status','')
        lics.save()
        messages.success(request, 'Successfully Updated')
    return redirect('/show_record')

  

@login_required
def delete_policy(request, id):  
    lics = Lic.objects.get(id=id)  
    lics.delete() 
    messages.success(request, 'Successfully Deleted')
    return redirect('/show_record')         


class SearchResultsView(ListView):
    model = Lic
    template_name = 'dashboard/search_results.html'
    
    def get_queryset(self):
        query = self.request.GET.get('q') # new
        object_list = Lic.objects.filter(
            Q(name__icontains=query) | Q(policy_number__icontains=query)
        )
        return object_list



def sort_record(request):
    user = User.objects.get(username = request.user)
    sorting = request.GET.get('sorting')
    lics = Lic.objects.filter(user__pk=user.id)
    active = Lic.objects.filter(user__pk=user.id,status=1).count()
    count = lics.count()
    # print(sorting)
    if sorting =='status':
        lics = Lic.objects.filter(user__pk=user.id,status=1).order_by('renew_date')
        return render(request,'dashboard/show_record.html',{
            'lics':lics,
             'count':count,
             'active':active

            })  
    else:
    
        lics = Lic.objects.filter(user__pk=user.id).order_by('-'+sorting)
        return render(request,'dashboard/show_record.html',{
            'lics':lics,
            'count':count,
             'active':active
            })  

# def counter(request):
#     user = User.objects.get(username = request.user)
#     lics = Lic.objects.filter(user__pk=user.id)
#     active = Lic.objects.filter(user__pk=user.id,status=1).count()
#     count = lics.count()
#     return render(request,'dashboard/base.html',{
#         'count':count,
#         'active':active
#     })

